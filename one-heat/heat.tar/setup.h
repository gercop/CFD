! some precompiler statements.

! time integration
! 1 Runge-Kutta second order (Heun)
! 2 SSP-Runge-Kutta third order and 4 stages
! 3 Runge-Kutta fourth order (standard)
#define TIME_INT 3

! two first or one second derivative

! 1 two first
! 2 one second derivative
#define SEC_DER 1
